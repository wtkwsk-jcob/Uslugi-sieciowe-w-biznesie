# -*- coding: utf-8 -*-
import fastf1.plotting
import seaborn as sns
from matplotlib import pyplot as plt
import PySimpleGUI as sg

# załadowanie sesji
fastf1.plotting.setup_mpl(misc_mpl_mods=False)

# Tworzenie układu GUI
layout = [
    [sg.Text("Podaj rok:"), sg.Input(key="-ROK-")],
    [sg.Text("Podaj numer wyścigu:"), sg.Input(key="-WYSCIG-")],
    [sg.Text("Podaj typ sesji (np. 'R' dla Race):"), sg.Input(key="-SESJA-")],
    [sg.Text("Podaj skrót kierowcy (np. 'VER' dla Verstappena):"), sg.Input(key="-KIEROWCA-")],
    [sg.Button("Wykonaj")]
]

# Tworzenie okna
window = sg.Window("Czas okrążenia kierowcy", layout)

# Pętla główna GUI
while True:
    event, values = window.read()

    # Zakończ pętlę, jeśli okno zostało zamknięte
    if event == sg.WINDOW_CLOSED:
        break

    # Wykonaj kod, jeśli przycisk "Wykonaj" został kliknięty
    if event == "Wykonaj":
        rok = int(values["-ROK-"])
        wyscig = int(values["-WYSCIG-"])
        sesja = values["-SESJA-"]
        kierowca = values["-KIEROWCA-"]

        race = fastf1.get_session(rok, wyscig, sesja)
        race.load()

        driver_laps = race.laps.pick_driver(kierowca).pick_quicklaps().reset_index()

        fig, ax = plt.subplots(figsize=(8, 8))
        sns.scatterplot(data=driver_laps,
                        x="LapNumber",
                        y="LapTime",
                        ax=ax,
                        hue="Compound",
                        palette=fastf1.plotting.COMPOUND_COLORS,
                        s=80,
                        linewidth=0,
                        legend='auto')
        ax.set_xlabel("Nr Okrążenia")
        ax.set_ylabel("Czas Okrążenia")
        ax.invert_yaxis()
        plt.suptitle(f"Czas okrążeń {kierowca} w Grand Prix Miami {rok}")
        plt.grid(color='w', which='major', axis='both')
        sns.despine(left=True, bottom=True)
        plt.tight_layout()
        plt.show()

# Zamknięcie okna
window.close()
