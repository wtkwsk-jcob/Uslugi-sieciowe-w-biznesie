# -*- coding: utf-8 -*-
import fastf1 as ff1
from fastf1 import utils
from matplotlib import pyplot as plt
import PySimpleGUI as sg

# włączenie funkcji cache do szybszego ładowania danych
ff1.Cache.enable_cache('cache')

# Tworzenie układu GUI
layout = [
    [sg.Text("Podaj rok:"), sg.Input(key="-ROK-")],
    [sg.Text("Podaj numer wyścigu:"), sg.Input(key="-WYSCIG-")],
    [sg.Text("Podaj typ sesji (np. R dla Race):"), sg.Input(key="-SESJA-")],
    [sg.Text("Podaj skrót pierwszego kierowcy (np. VER dla Verstappena):"), sg.Input(key="-DRIVER1-")],
    [sg.Text("Podaj skrót drugiego kierowcy (np. ALO dla Alonso):"), sg.Input(key="-DRIVER2-")],
    [sg.Button("Wykonaj")]
]

# Tworzenie okna
window = sg.Window("Porównanie kierowców", layout)

# Pętla główna GUI
while True:
    event, values = window.read()

    # Zakończ pętlę, jeśli okno zostało zamknięte
    if event == sg.WINDOW_CLOSED:
        break

    # Wykonaj kod, jeśli przycisk "Wykonaj" został kliknięty
    if event == "Wykonaj":
        rok = int(values["-ROK-"])
        grand_prix = int(values["-WYSCIG-"])
        sesja = values["-SESJA-"]
        driver_1 = values["-DRIVER1-"]
        driver_2 = values["-DRIVER2-"]

        #załadowanie sesji wyścigu
        race = ff1.get_session(rok, grand_prix, sesja)
        race.load()

        #pobranie statystyk okrążeń tych kierowców
        laps_driver_1 = race.laps.pick_driver(driver_1)
        laps_driver_2 = race.laps.pick_driver(driver_2)

        #wybór najszybszego okrążenia kierowców
        fastest_driver_1 = laps_driver_1.pick_fastest()
        fastest_driver_2 = laps_driver_2.pick_fastest()

        #pobranie telemetrii
        telemetry_driver_1 = fastest_driver_1.get_telemetry().add_distance()
        telemetry_driver_2 = fastest_driver_2.get_telemetry().add_distance()

        #pobranie czasu delty między kierowcami
        delta_time, ref_tel, compare_tel = utils.delta_time(fastest_driver_1, fastest_driver_2)

        #tworzenie wykresu
        plot_size = [15, 15]
        plot_title = f"{race.event.year} {race.event.EventName} - {race.name} - {driver_1} VS {driver_2}"
        #ustawienie stosunku wielkości poszczególnych wykresów
        plot_ratios = [1, 3, 2, 1, 1, 2, 1]
        plot_filename = plot_title.replace(" ", "") + ".png"

        plt.rcParams['figure.figsize'] = plot_size

        fig, ax = plt.subplots(7, gridspec_kw={'height_ratios': plot_ratios})

        #tytuł wykresu
        ax[0].title.set_text(plot_title)

        #linia delty
        ax[0].plot(ref_tel['Distance'], delta_time, color="darkgreen")
        ax[0].axhline(0)
        ax[0].set(ylabel=f"Przerwa do {driver_2} (s)")

        #prędkość
        ax[1].plot(telemetry_driver_1['Distance'], telemetry_driver_1['Speed'], label=driver_1,
                   color="darkgreen")
        ax[1].plot(telemetry_driver_2['Distance'], telemetry_driver_2['Speed'], label=driver_2,
                   color="#fcb605")
        ax[1].set(ylabel='Prędkość')
        ax[1].legend(loc="lower right")

        #Procent naciśnięcia przepustnicy
        ax[2].plot(telemetry_driver_1['Distance'], telemetry_driver_1['Throttle'], label=driver_1,
                   color="darkgreen")
        ax[2].plot(telemetry_driver_2['Distance'], telemetry_driver_2['Throttle'], label=driver_2,
                   color="#fcb605")
        ax[2].set(ylabel='Przepustnica (%)')

        #Procent naciśnięcia hamulców
        ax[3].plot(telemetry_driver_1['Distance'], telemetry_driver_1['Brake'], label=driver_1,
                   color="darkgreen")
        ax[3].plot(telemetry_driver_2['Distance'], telemetry_driver_2['Brake'], label=driver_2,
                   color="#fcb605")
        ax[3].set(ylabel='Hamulce (%)')

        #Używany w danym momencie bieg
        ax[4].plot(telemetry_driver_1['Distance'], telemetry_driver_1['nGear'], label=driver_1,
                   color="darkgreen")
        ax[4].plot(telemetry_driver_2['Distance'], telemetry_driver_2['nGear'], label=driver_2,
                   color="#fcb605")
        ax[4].set(ylabel='Bieg')

        # RPM silnika
        ax[5].plot(telemetry_driver_1['Distance'], telemetry_driver_1['RPM'], label=driver_1,
                   color="darkgreen")
        ax[5].plot(telemetry_driver_2['Distance'], telemetry_driver_2['RPM'], label=driver_2,
                   color="#fcb605")
        ax[5].set(ylabel='RPM')

        # Użycie DRS
        ax[6].plot(telemetry_driver_1['Distance'], telemetry_driver_1['DRS'], label=driver_1,
                   color="darkgreen")
        ax[6].plot(telemetry_driver_2['Distance'], telemetry_driver_2['DRS'], label=driver_2,
                   color="#fcb605")
        ax[6].set(ylabel='DRS')
        ax[6].set(xlabel='Długość okrążenia (metry)')

        # Schowanie etykiet na osi x oprócz tej na samym dole
        for a in ax.flat:
            a.label_outer()

        plt.savefig(plot_filename, dpi=300)
        plt.show()

# Zamknięcie okna
window.close()
