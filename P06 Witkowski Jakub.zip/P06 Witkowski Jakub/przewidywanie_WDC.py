# -*- coding: utf-8 -*-
import fastf1
from fastf1.ergast import Ergast
import PySimpleGUI as sg

def ranking_kierowcow():
    ergast = Ergast()
    ranking = ergast.get_driver_standings(season=2023)
    return ranking.content[0]

def obliczanie_max_punktow():
    punkty_za_sprint = 8 + 25 + 1  # Wygranie sprintu, wyścigu i zdobycie najszybszego okrążenia
    punkty_za_wyscig = 25 + 1  # Wygranie wyścigu i zdobycie najszybszego okrążenia

    events = fastf1.events.get_events_remaining(force_ergast=True)
    # Obliczanie ile zostało jeszcze wyścigów
    sprinty = len(events.loc[events["EventFormat"] == "sprint"])
    wyscigi = len(events.loc[events["EventFormat"] == "conventional"])

    # Obliczanie punktów
    punkty_sprint = sprinty * punkty_za_sprint
    punkty_wyscig = wyscigi * punkty_za_wyscig

    return punkty_sprint + punkty_wyscig

def kto_moze_wygrac(ranking_kierowcow, max_punktow):
    punkty_lidera = int(ranking_kierowcow.loc[0]['points'])

    for i, _ in enumerate(ranking_kierowcow.iterrows()):
        kierowca = ranking_kierowcow.loc[i]
        max_punktow_kierowcy = int(kierowca["points"]) + max_punktow
        czy_moze_wygrac = 'No' if max_punktow_kierowcy < punkty_lidera else 'Yes'

        print(f"{kierowca['position']}: {kierowca['givenName'] + ' ' + kierowca['familyName']}, "
              f"Current points: {kierowca['points']}, "
              f"Theoretical max points: {max_punktow_kierowcy}, "
              f"Can win: {czy_moze_wygrac}")

layout = [
    [sg.Button("Wyświetl ranking kierowców")],
    [sg.Button("Wyświetl potencjalnych zwycięzców")],
    [sg.Button("Zamknij")]
]

window = sg.Window("FastF1", layout, margins=(400,300))

while True:
    event, _ = window.read()
    if event == sg.WINDOW_CLOSED or event == "Zamknij":
        break

    if event == "Wyświetl ranking kierowców":
        ranking_kierowcow2 = ranking_kierowcow()
        sg.popup(f"Aktualny ranking kierowców:\n\n{ranking_kierowcow2}", title="Ranking kierowców")

    elif event == "Wyświetl potencjalnych zwycięzców":
        ranking_kierowcow2 = ranking_kierowcow()
        punkty = obliczanie_max_punktow()
        potencjalni_zwyciezcy = []

        punkty_lidera = int(ranking_kierowcow2.loc[0]['points'])

        for i, _ in enumerate(ranking_kierowcow2.iterrows()):
            kierowca = ranking_kierowcow2.loc[i]
            max_punktow_kierowcy = int(kierowca["points"]) + punkty
            czy_moze_wygrac = 'No' if max_punktow_kierowcy < punkty_lidera else 'Yes'

            potencjalni_zwyciezcy.append(f"{kierowca['position']}: {kierowca['givenName'] + ' ' + kierowca['familyName']}, "
                                         f"Current points: {kierowca['points']}, "
                                         f"Theoretical max points: {max_punktow_kierowcy}, "
                                         f"Can win: {czy_moze_wygrac}")

        sg.popup('\n\n'.join(potencjalni_zwyciezcy), title="Potencjalni zwycięzcy")

window.close()
