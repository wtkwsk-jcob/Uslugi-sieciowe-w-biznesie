# -*- coding: utf-8 -*-
import fastf1.plotting
import matplotlib.pyplot as plt
import PySimpleGUI as sg

# Załadowanie nowej sesji i tworzenie wykresu
fastf1.plotting.setup_mpl(misc_mpl_mods=False)

layout = [
    [sg.Text("Podaj rok: "), sg.InputText(key="-YEAR-")],
    [sg.Text("Podaj numer wyścigu: "), sg.InputText(key="-RACE-")],
    [sg.Text("Podaj typ sesji (np. R dla Race): "), sg.InputText(key="-SESSION-")],
    [sg.Button("Wykonaj")]
]

window = sg.Window("FastF1", layout)

while True:
    event, values = window.read()
    if event == sg.WINDOW_CLOSED:
        break

    rok = int(values["-YEAR-"])
    grand_prix = int(values["-RACE-"])
    sesja = values["-SESSION-"]

    sesja = fastf1.get_session(rok, grand_prix, sesja)
    sesja.load(telemetry=False, weather=False)

    fig, ax = plt.subplots(figsize=(8.0, 4.9))

    for drv in sesja.drivers:
        drv_laps = sesja.laps.pick_driver(drv)  # wydobycie 3 pierwszych liter z nazwiska kierowcy pobierając wartosc z 1 okr

        skr = drv_laps['Driver'].iloc[0]
        kolor = fastf1.plotting.driver_color(skr)  # pobranie i przypisanie do nich koloru

        ax.plot(drv_laps['LapNumber'], drv_laps['Position'],  # umieszczenie ich pozycji na wykresie
                label=skr, color=kolor)

    # dodanie limitu dla osi y tak, aby kierowca na pozycji pierwszej był na górze
    ax.set_ylim([20.5, 0.5])
    ax.set_yticks([1, 5, 10, 15, 20])
    ax.set_xlabel('Okrążenie')
    ax.set_ylabel('Pozycja')
    # dodanie legendy
    ax.legend(bbox_to_anchor=(1.0, 1.02))
    plt.tight_layout()

    plt.show()

window.close()
